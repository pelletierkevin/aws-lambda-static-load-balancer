# aws-lambda
Python code for AWS LAmbda function to get and populate private IPv4 addresses of load balancer to another network load balancer


Modified version of Lambda python code zip file from (STEP 4) https://aws.amazon.com/blogs/networking-and-content-delivery/using-static-ip-addresses-for-application-load-balancers/
